#include <vector>

using std::vector;

vector<double> storage_cpp(vector<double> demanded, vector<double> produced, double storage_power,
    double storage_energy, double eff_charge, double eff_discharge, double time_step);
